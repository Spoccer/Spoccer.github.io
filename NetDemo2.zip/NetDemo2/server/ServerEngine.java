package server;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.Timer;
import shared.AnimationPanel; 
import shared.GenericComm;

public class ServerEngine extends AnimationPanel implements ActionListener
{
//    private Game theGame;
        
    private int numPlayers = 0;
    public static int maxPlayers = 9;
//    Color[] colors = new Color[] {Color.BLUE, Color.GREEN, Color.YELLOW, Color.PINK}; 
    private boolean timedMoves = true;
    private ArrayList<Player> players = new ArrayList<Player>();
    
    
    //Constructor
    public ServerEngine() {
        super("CGCT demo - SERVER", 600, 400);
        //initialize variables
//       initTimer();
    }
    
    /**
     * When a new player joins on the server, this method is called
     * to add the player to the game.  
     * ONLY ADD FOUR PLAYERS!!!
     * @param p 
     */
    public void addNewPlayer(int num, String name)
    { 
        debugMsg("SSEngine:AddedNewStation");
//        Player newPlayer = new Player(num, name);
//        players.add(newPlayer);
        //Send a hello message and a goal. 
        
    }
    
    /**
     * Something needs to trigger the game actually starting...
     * Maybe once four players arrive?
     * Maybe the players can click and if there isn't four yet, Bots added?
     * 
     * This method will dealFourTiles, then let the first player know to go.
     */
     
    /**
     * This method receives a message from a client and updates the game
     * accordingly.
     * This method will need to determine all of the messages that might
     * be sent from the client.  (Tile selected, Tile placed, start game,...???)
     * @param theInput
     * @param myConnNumber
     */
    public String processInput(String theInput, int stationNum) 
    {        
        debugMsg("@ processInput, theInput:" + theInput + " at stationNum: " + stationNum);
        if(theInput.startsWith("CHECKIN"))
        {
            int playerNum = Integer.parseInt(theInput.substring(7));
            Player p = findPlayerByNum(playerNum);
            if(p != null)
                return p.updateLocation(stationNum);
        }
        else if (theInput.startsWith("JOIN"))
        {
            String name = theInput.substring(4);
            int nextPlayerNum = players.size();
            Player newPlayer = new Player(nextPlayerNum,name);
            newPlayer.setGoal();
            players.add(newPlayer);
            return "HELLO,"+nextPlayerNum+","+name;
//            return "Welcome, "+name+" you have joined as player # "+nextPlayerNum+" and goal "+newPlayer.getDestination();
        }
        return "Couldn't decide what to say!";
    }
    
    
    public Player findPlayerByNum(int num)
    {
        for(Player p: players)
            if(p.getIDnum()==num)
                return p;
        return null;
    }
    /**
     * On the server side, we should always view the game in the
     * four player view.  
     * @param g
     * @return 
     */
    protected void renderFrame(Graphics g) {
        //Draw the entire display.  
        
        //General Text (Draw this last to make sure it's on top.)
        g.setColor(Color.BLACK);
        g.drawString("SERVER", 10, 24);
        g.drawString("frame=" + frameNumber, 200, 24);
       

    }//--end of renderFrame method--
    //-------------------------------------------------------
    //Respond to Keyboard Events
    //-------------------------------------------------------
    public void keyTyped(KeyEvent e) 
    {
        char c = e.getKeyChar(); 
    }
    
    /**
     * Just a useful debugging tool.  
     * If we use this instead of System.out.println() 
     * we can turn them all off in one place.  
     * @param msg - the debugging message to be displayed. 
     */
    private void debugMsg(String msg)
    {
        if(GenericComm.debugMode)
            System.out.println(msg);
    }
    
    //----------------------------
    //  Removing slow players...
    //----------------------------
    private Timer timer;
    private final int DELAY = 40000; //delay in mSec
    private void initTimer()
    {   //Set up a timer that calls this object's action handler.
        timer = new Timer(DELAY, this);
        timer.setInitialDelay(DELAY);
        timer.setCoalesce(true);
//        timer.start();
    }
    public void startTimer()
    {
        timer.restart();
    }
    public void stopTimer()
    {
        timer.stop();  
    }
    
    public void actionPerformed(ActionEvent e) 
    {
    }
}
