package server;

/**
 *
 * @author spockm
 */
public class Player 
{
    int IDnum;
    String name;
    long lastCheckInTime;
    int lastCheckInLocation;
    int currentDestination;
    
    public Player(int id, String n)
    {
        IDnum = id;
        name = n;
        lastCheckInTime = System.currentTimeMillis();
        lastCheckInLocation = 999;
        currentDestination = 888;
    }
    
    public int getIDnum() { return IDnum; }
    public int getDestination() { return currentDestination; }
    
    public String updateLocation(int loc)
    {
        lastCheckInLocation = loc; 
        if(loc == currentDestination)
            return "Congrats, "+name+". You made it!";
        else
            return name+", this is the wrong place! Go to #"+currentDestination;
    }
    
    public void setGoal()
    {
        int randomDest = (int)(Math.random()*SS_Thread.getNumStations());
        while(randomDest == currentDestination && SS_Thread.getNumStations()>1)
            randomDest = (int)(Math.random()*SS_Thread.getNumStations());
        currentDestination = randomDest;
    }
}
