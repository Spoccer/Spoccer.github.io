package client;

/**
 * Class ClientSideGameEngine
 * This is based off of the ArcadeDemo.  
 */

import java.applet.AudioClip;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import shared.AnimationPanel;
import shared.GenericComm;


public class ClientEngine extends AnimationPanel implements ActionListener
{
    //Constants
    //-------------------------------------------------------
    private boolean COMMUNICATION_ON = true;
    private boolean CHEATS_ON = false;
    
    //Instance Variables
    //-------------------------------------------------------
    
    //Network variables
    //-------------------------------------------------------
    private int myID; //for Networking
    private Timer timer;
    private final int DELAY = 500; //delay in mSec
    private GenericComm comm;
    String displayMessage = "No message.";
    String response = "";
    
    //Constructor
    //-------------------------------------------------------
    public ClientEngine()
    {   //Enter the name and width and height.  
        super("Client Window", 600, 500);
        
        if(COMMUNICATION_ON)
        {
            comm = new GenericComm();
//            comm.setDebugValues("C_COMM",0); 
            myID = -1;  //Until I get a WELCOME message...
            initTimer();
        }
    }

    /**
     * This updates the animation view every frame.  
     * @param g
     */       
    @Override
    protected void renderFrame(Graphics g) 
    {
        g.setFont(new Font("Helvetica", Font.BOLD, 22));
        g.drawString("CGCT Client #"+myID, 30, 35);
        g.drawString("msg= "+displayMessage, 25,100);
    }//--end of renderFrame method--

//    private long turnStartTime = 0;
//    public final int MAX_TURN_TIME = 40000;
//    public void checkTime(Graphics g)
//    {
//    }
    
    //-------------------------------------------------------
    //Respond to Mouse Events
    //-------------------------------------------------------
    public void mouseClicked(MouseEvent e)  
    {
    }
    
    //-------------------------------------------------------
    //Respond to Keyboard Events
    //-------------------------------------------------------
    public void keyTyped(KeyEvent e) 
    {
        char c = e.getKeyChar(); 
//        if(c=='v' || c=='V')  //Toggle the view mode 1 or 4 grids
//            viewFourGrids = !viewFourGrids;
        if(c=='j')
        {
            String playerName = JOptionPane.showInputDialog
                         ("Please enter your name", "name");
            String message = "JOIN"+playerName;
            comm.sendMessage(message);

//            System.out.println("j pressed    + "+response);
        }
        if(c >= '0' && c <='9') //number 
        {
            String message = "CHECKIN"+c;
            comm.sendMessage(message);
            
//            System.out.println(c+" pressed   + "+response);
        }
    }
    
    
    //-------------------------------------------------------
    //Initialize Graphics
    //-------------------------------------------------------       
//    private Image startScreenImage;
    
    public void initGraphics() 
    {      
//        Square.initGraphics();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
//        startScreenImage = toolkit.getImage("KDtitle.png");
    } //--end of initGraphics()--
    
    //-------------------------------------------------------
    //Initialize Sounds
    //-------------------------------------------------------
    
    AudioClip Music1;
    public void initMusic() 
    {
//        Music1 = loadClip("Medievil.wav");
    }


    //*********************************************************
    // NETWORK STUFF
    //*********************************************************
    private void initTimer()
    {   //Set up a timer that calls this object's action handler.
        timer = new Timer(DELAY, this);
        timer.setInitialDelay(DELAY);
        timer.setCoalesce(true);
        timer.start();
    }
    public void sendMessage(String choice)
    {
        comm.sendMessage(choice); 
        do {
            response = comm.getMessage();
        }  while (comm.messageWaiting());
    }
    
    /**
     * This method is called whenever the Timer goes off, 
     * causing the Client to send a message to the server, 
     * and receive the entire Game in response.  
     * It also handles WELCOME messages.  
     * @param e 
     */
    public void actionPerformed(ActionEvent e) 
    {   
        //Send a message to the server requesting an update... 
//        String message = "UPDATE";
//        comm.sendMessage(message);
        //Receive a reply from the server.  
        if(myID == -1) //Need to listen to all until I get WELCOME
            response = comm.getMessage();
        else //typically just take the most recent message.  
            response = comm.getMostRecentMessage();

        //Choose how to deal with the message... 
        if(response == null)
        { 
//            response = "No response."; 
        }
        else if(response.startsWith("INFO"))
        {
            displayMessage = response;
            //Unpack the entire game.  
//            gameBoard.unpack(response);
            System.out.println("CSGE_KD:"+response);
        }
        else if(response.startsWith("WELCOME"))
        {
            displayMessage = response;
            String[] parts = response.split(",");
            myID = Integer.parseInt(parts[1]); 
            //Tell the server my name... 
            comm.sendMessage("NAME,"+myID+","+comm.getUserName());
        }
        else
        {
            displayMessage = response;
            response = "???: "+response;
            debugMsg(response);
        }
    }   //end of actionPerformed()    
    
    
    private void debugMsg(String m)
    {
        if(GenericComm.debugMode)
            System.out.println(m);
    }

}//--end of ArcadeDemo class--

