package shared;

/**
 *
 * @author spockm
 */
public class Player {
    
}
